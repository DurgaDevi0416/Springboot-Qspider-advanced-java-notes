package oneToOneUnidirectionalMapping;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class PersonAadhaarMain {

	public static void main(String[] args) {
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("dev");
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
	
		Person p = new Person();
		p.setPersonid(1);
		p.setName("Sheela");
		p.setAddress("bangalore");
		
		Aadhar aadhar = new Aadhar();
		aadhar.setAadharid(1);
		aadhar.setAadharno(72072481699L);
		
		p.setAadhar(aadhar);
		
		transaction.begin();
		manager.persist(p);
		manager.persist(aadhar);
		transaction.commit();
	}
}













