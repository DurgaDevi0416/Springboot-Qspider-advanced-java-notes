package oneToOneUnidirectionalMapping;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Aadhar {

	@Id
	private int aadharid;
	private long aadharno;
	
	public int getAadharid() {
		return aadharid;
	}
	public void setAadharid(int aadharid) {
		this.aadharid = aadharid;
	}
	public long getAadharno() {
		return aadharno;
	}
	public void setAadharno(long aadharno) {
		this.aadharno = aadharno;
	}
	
	
}













