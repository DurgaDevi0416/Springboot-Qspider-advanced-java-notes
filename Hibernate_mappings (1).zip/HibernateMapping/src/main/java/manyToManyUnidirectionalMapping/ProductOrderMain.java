package manyToManyUnidirectionalMapping;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class ProductOrderMain {

	public static void main(String[] args) {
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("dev");
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
	
		Order order1 = new Order();
		order1.setOrderid(1);
		order1.setCustomerName("Sheela");
	
		Product product1 = new Product();
		product1.setProductId(1);
		product1.setPname("Laptop");
		product1.setPrice(5000);
		
		Product product2 = new Product();
		product2.setProductId(2);
		product2.setPname("Mouse");
		product2.setPrice(2500);
		
		List<Product> productList1 = new ArrayList<Product>();
		productList1.add(product1);
		productList1.add(product2);
		
		order1.setProducts(productList1);
		
		
		
		Order order2 = new Order();
		order2.setOrderid(2);
		order2.setCustomerName("Ram");
				
		Product product3 = new Product();
		product3.setProductId(3);
		product3.setPname("Keyboard");
		product3.setPrice(3000);
		
		Product product4 = new Product();
		product4.setProductId(4);
		product4.setPname("Speakers");
		product4.setPrice(4000);
		
		List<Product> productList2 = new ArrayList<Product>();
		productList2.add(product1);
		productList2.add(product3);
		productList2.add(product4);
	
		order2.setProducts(productList2);
		
		transaction.begin();
		manager.persist(order1);
		manager.persist(order2);
		manager.persist(product1);
		manager.persist(product2);
		manager.persist(product3);
		manager.persist(product4);
		transaction.commit();
	}
}























