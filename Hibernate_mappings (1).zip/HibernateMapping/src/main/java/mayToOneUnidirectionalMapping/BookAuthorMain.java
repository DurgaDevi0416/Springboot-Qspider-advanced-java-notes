package mayToOneUnidirectionalMapping;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class BookAuthorMain {

	public static void main(String[] args) {
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("dev");
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
	
		Book book1 = new Book();
		book1.setBookid(1);
		book1.setTitle("Avengers");
		book1.setPrice(1200);
		
		Book book2 = new Book();
		book2.setBookid(2);
		book2.setTitle("Harry Potter");
		book2.setPrice(750);
		
		Book book3 = new Book();
		book3.setBookid(3);
		book3.setTitle("Sleeping Beauty");
		book3.setPrice(560);
		
		Author author = new Author();
		author.setAuthorId(1);
		author.setName("James Bond");
		
		book1.setAuthor(author);
		book2.setAuthor(author);
		book3.setAuthor(author);
		
		transaction.begin();
		manager.persist(author);
		manager.persist(book1);
		manager.persist(book2);
		manager.persist(book3);
		transaction.commit();
	}
}















