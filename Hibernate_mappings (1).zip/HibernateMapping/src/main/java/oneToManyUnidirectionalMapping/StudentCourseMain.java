package oneToManyUnidirectionalMapping;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class StudentCourseMain {

	public static void main(String[] args) {
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("dev");
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
	
		Student student = new Student();
		student.setStudentid(1);
		student.setName("Ram");
		student.setAddress("bangalore");
		
		Course course1 = new Course();
		course1.setCourseid(1);
		course1.setName("JAVA");
		course1.setFees(3500);
		course1.setDuration(3);
		
		Course course2 = new Course();
		course2.setCourseid(2);
		course2.setName("SQL");
		course2.setFees(1700);
		course2.setDuration(1);
		
		Course course3 = new Course();
		course3.setCourseid(3);
		course3.setName("WEB TECH");
		course3.setFees(2500);
		course3.setDuration(2);
		
		List<Course> courseList = new ArrayList<Course>();
		courseList.add(course1);
		courseList.add(course2);
		courseList.add(course3);
		
		student.setCourses(courseList);
		
		transaction.begin();
		manager.persist(student);
		manager.persist(course1);
		manager.persist(course2);
		manager.persist(course3);
		transaction.commit();
	}
}
















