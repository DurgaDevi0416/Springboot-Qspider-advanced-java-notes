package oneToOneBidirectionalMapping;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class EmployeeAddressMain {

	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("dev");
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
	
		Employee emp = new Employee();
		emp.setEmpid(1);
		emp.setName("Ram");
		emp.setSalary(25000);
		emp.setDesignation("HR");
		
		Address address = new Address();
		address.setAddressid(1);
		address.setCity("delhi");
		address.setPincode(560064);
		
		emp.setAddress(address);
		address.setEmployee(emp);
		
		transaction.begin();
		manager.persist(address);
		manager.persist(emp);
		transaction.commit();
	}
}
















