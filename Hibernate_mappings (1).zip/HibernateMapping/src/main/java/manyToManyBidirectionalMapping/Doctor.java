package manyToManyBidirectionalMapping;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Doctor {

	@Id
	private int doctorId;
	private String name;
	private String speciaization;
	
	@ManyToMany
	private List<Patient> patientList = 
						new ArrayList<Patient>();

	public int getDoctorId() {
		return doctorId;
	}

	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSpeciaization() {
		return speciaization;
	}

	public void setSpeciaization(String speciaization) {
		this.speciaization = speciaization;
	}

	public List<Patient> getPatientList() {
		return patientList;
	}

	public void setPatientList(List<Patient> patientList) {
		this.patientList = patientList;
	}

	
}















