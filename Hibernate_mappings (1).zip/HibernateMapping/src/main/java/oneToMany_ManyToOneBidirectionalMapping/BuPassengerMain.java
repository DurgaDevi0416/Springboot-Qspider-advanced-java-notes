package oneToMany_ManyToOneBidirectionalMapping;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class BuPassengerMain {

	public static void main(String[] args) {
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("dev");
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		
		Bus bus = new Bus();
		bus.setBusid(1);
		bus.setTravelsName("SRS travels");
		bus.setTicketPrice(250);
		
		Passenger p1 = new Passenger();
		p1.setPassengerId(1);
		p1.setName("Sheela");
		p1.setGender("Female");
		
		Passenger p2 = new Passenger();
		p2.setPassengerId(2);
		p2.setName("Ram");
		p2.setGender("Male");

		Passenger p3 = new Passenger();
		p3.setPassengerId(3);
		p3.setName("Mala");
		p3.setGender("Female");
		
		List<Passenger> passengerList = new ArrayList<Passenger>();
		passengerList.add(p1);
		passengerList.add(p2);
		passengerList.add(p3);
		
		bus.setPassengers(passengerList);
		
		p1.setBus(bus);
		p2.setBus(bus);
		p3.setBus(bus);
		
		transaction.begin();
		manager.persist(p1);
		manager.persist(p2);
		manager.persist(p3);
		manager.persist(bus);
		transaction.commit();
	}
}















