package unidirectional_ManyToOneMapping;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class BookAuthorMain {

	public static void main(String[] args) {
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("dev");
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
	
		Book book1 = new Book();
		book1.setBookid(1);
		book1.setTitle("Harry Potter");
		book1.setPrice(780);
		
		Book book2 = new Book();
		book2.setBookid(2);
		book2.setTitle("Avengers");
		book2.setPrice(1200);
		
		Book book3 = new Book();
		book3.setBookid(3);
		book3.setTitle("Sleeping Beauty");
		book3.setPrice(650);
		
		Author author = new Author();
		author.setAuthorid(1);
		author.setName("William Robert");
		
		// setting multiple books to one author
		book1.setAuthor(author);
		book2.setAuthor(author);
		book3.setAuthor(author);
		
		transaction.begin();
		manager.persist(book1);
		manager.persist(book2);
		manager.persist(book3);
		manager.persist(author);
		transaction.commit();
	}
}













