package bidirectional_OneToOneMapping;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class EmployeeAddressMain {

	public static void main(String[] args) {
	
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("dev");
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
	
		Employee emp =  new Employee();
		emp.setEmpid(1);
		emp.setName("Rahul");
		emp.setSalary(56000);
		emp.setDesignation("HR");
		
		Address addr = new Address();
		addr.setAddressid(101);
		addr.setCity("Bangalore");
		addr.setPincode(560064);
		
		emp.setAddress(addr);
		
		addr.setEmployee(emp);
		
		transaction.begin();
		manager.persist(emp);
		manager.persist(addr);
		transaction.commit();
	}
}













