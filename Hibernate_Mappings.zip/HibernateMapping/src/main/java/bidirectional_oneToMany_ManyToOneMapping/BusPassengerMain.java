package bidirectional_oneToMany_ManyToOneMapping;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class BusPassengerMain {

	public static void main(String[] args) {
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("dev");
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
	
		Bus bus = new Bus();
		bus.setBusid(111);
		bus.setTravelsName("SRS Travels");
		bus.setPrice(250);
		
		Passenger p1 = new Passenger();
		p1.setPassengerid(1);
		p1.setName("Sheela");
		p1.setGender("female");
		
		Passenger p2 = new Passenger();
		p2.setPassengerid(2);
		p2.setName("Ram");
		p2.setGender("male");
		
		Passenger p3 = new Passenger();
		p3.setName("Amar");
		p3.setPassengerid(3);
		p3.setGender("male");
		
		List<Passenger> passengerList = new ArrayList<Passenger>();
		passengerList.add(p1);
		passengerList.add(p2);
		passengerList.add(p3);
		
		// one bus mapped to many passenger
		bus.setPassengers(passengerList);
		
		// many passengers mapped to one bus
		p1.setBus(bus);
		p2.setBus(bus);
		p3.setBus(bus);
		
		transaction.begin();
		manager.persist(bus);
		manager.persist(p1);
		manager.persist(p2);
		manager.persist(p3);
		transaction.commit();
	}
}












