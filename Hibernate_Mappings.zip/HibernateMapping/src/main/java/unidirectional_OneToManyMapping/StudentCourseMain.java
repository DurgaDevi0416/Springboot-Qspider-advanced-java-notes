package unidirectional_OneToManyMapping;

import java.awt.geom.Arc2D;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class StudentCourseMain {

	public static void main(String[] args) {
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("dev");
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		
		Student s = new Student();
		s.setStudentid(1);
		s.setName("Mala");
		s.setPhoneNo(9876543218L);
		
		Course cours1 = new Course();
		cours1.setCourseid(1);
		cours1.setName("Java");
		cours1.setFees(3500);
		
		Course cours2 = new Course();
		cours2.setCourseid(2);
		cours2.setName("SQL");
		cours2.setFees(1700);
		
		Course cours3 = new Course();
		cours3.setCourseid(3);
		cours3.setName("Web Technology");
		cours3.setFees(2400);
		
		List<Course> courseList = new ArrayList<Course>();
		courseList.add(cours1);
		courseList.add(cours2);
		courseList.add(cours3);
		
		s.setCourses(courseList);
		
		transaction.begin();
		manager.persist(cours1);
		manager.persist(cours2);
		manager.persist(cours3);
		manager.persist(s);
		transaction.commit();
	}
}











