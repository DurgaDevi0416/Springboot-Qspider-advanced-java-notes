package bidirectional_manyToMany;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class DoctorPatientMain {

	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("dev");
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
	
		Doctor d1 = new Doctor();
		d1.setDoctorid(1);
		d1.setName("Dr. Ramesh");
		d1.setSpecialization("Cardiology");
		
		Doctor d2 = new Doctor();
		d2.setDoctorid(2);
		d2.setName("Dr. Kavya");
		d2.setSpecialization("Dentist");
		
		Patient p1 = new Patient();
		p1.setPatientid(1);
		p1.setName("amar");
		p1.setAge(28);
		
		Patient p2 = new Patient();
		p2.setPatientid(2);
		p2.setName("lakshmi");
		p2.setAge(65);
		
		// In patient class , already Doctor list is present . So ,getting that list
		// and to this list , add doctor objects
		p1.getDoctorList().add(d1);
		p1.getDoctorList().add(d2);
	
		// adding doctor d2 to the doctor list of patient p2
		p2.getDoctorList().add(d2);
		
		// In doctor class , already Patient List is present. So , getting that list for doctor d1
		// and to this list , adding patient p1 object 
		d1.getPatientList().add(p1);
		
		// getting the patient list for doctor d2 and adding patients p1 and p2 to it.
		d2.getPatientList().add(p1);
		d2.getPatientList().add(p2);
		
		// insert all objects into DB
		transaction.begin();
		manager.persist(d1);
		manager.persist(d2);
		manager.persist(p1);
		manager.persist(p2);
		transaction.commit();

	}
}













