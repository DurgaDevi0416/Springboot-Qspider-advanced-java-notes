package Unidirectional_manyToManyMapping;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class DeveloperProject {

	public static void main(String[] args) {	

		EntityManagerFactory factory = Persistence.createEntityManagerFactory("dev");
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
	
		Developer dev1 = new Developer();
		dev1.setDeveloperid(1);
		dev1.setName("ram");
		dev1.setSalary(500000);
		
		Project p1 = new Project();
		p1.setProjectid(111);
		p1.setTitle("Banking Application");
		
		Project p2 = new Project();
		p2.setProjectid(222);
		p2.setTitle("E-Commerce");
		
		List<Project> dev1ProjectList = new ArrayList<Project>();
		dev1ProjectList.add(p1);
		dev1ProjectList.add(p2);
		
		Developer dev2 = new Developer();
		dev2.setDeveloperid(2);
		dev2.setName("mala");
		dev2.setSalary(75000);
		
		Project p3 = new Project();
		p3.setProjectid(333);
		p3.setTitle("Hospital Management");
		
		Project p4 = new Project();
		p4.setProjectid(444);
		p4.setTitle("Online payment App");

		List<Project> dev2ProjectList = new ArrayList<Project>();
		dev2ProjectList.add(p3);
		dev2ProjectList.add(p4);
		dev2ProjectList.add(p2);
		
		dev1.setProjects(dev1ProjectList);
		dev2.setProjects(dev2ProjectList);
		
		transaction.begin();
		manager.persist(dev1);
		manager.persist(dev2);
		manager.persist(p1);
		manager.persist(p2);
		manager.persist(p3);
		transaction.commit();
	}
}













