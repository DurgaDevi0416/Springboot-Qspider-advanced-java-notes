package static_programs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class SearchingAndFetchingStudentObjectById {

	public static void main(String[] args) {
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("dev");
		EntityManager manager = factory.createEntityManager();
		
		// find() --> search and retrieve an object based on primary key 
		Student s = manager.find(Student.class , 1);
		
		if(s != null) {
			System.out.println("STUDENT ID : "+s.getSid());
			System.out.println("NAME : "+s.getName());
			System.out.println("AGE : "+s.getAge());
		}
		else {
			System.out.println("STUDENT ID DOESNT EXIST");
		}
	}
}
