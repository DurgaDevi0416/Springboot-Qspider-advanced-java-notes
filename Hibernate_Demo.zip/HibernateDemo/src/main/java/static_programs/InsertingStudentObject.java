package static_programs;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class InsertingStudentObject {

	public static void main(String[] args) {
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("dev");
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		
		Scanner sc = new Scanner(System.in);
		
		Student s = new Student();
		s.setSid(1);
		s.setName("Sheela");
		s.setAge(25);
		
		transaction.begin();
		manager.persist(s);
		System.out.println("Student details are stored.");
		transaction.commit();
	}
}












