package static_programs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class UpdatingStudentObject {

	public static void main(String[] args) {
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("dev");
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		
	    Student s = manager.find(Student.class, 1);
	    
	    if(s!= null) {
	    	
	    	s.setName("Sheela Kumari");
	    	transaction.begin();
	    	manager.merge(s);
	    	System.out.println("updation done");
	    	transaction.commit();
	    }
	    else {
	    	System.out.println("STUDENT ID DOESNT EXIST");
	    }
	}
}











