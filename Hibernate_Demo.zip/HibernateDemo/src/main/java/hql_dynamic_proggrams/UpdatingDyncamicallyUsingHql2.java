package hql_dynamic_proggrams;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class UpdatingDyncamicallyUsingHql2 {

public static void main(String[] args) {
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("dev");
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		
// WAP to create select dynamic HQL query using named paramater to fetch all objects from DB 
								// whose name = (take from user)  
		
		// Create dynamic HQL query using named parameters
		Query q = manager.createQuery("update Student s set s.name=:sname where s.sid=:stuid ");
		
		// take input from user
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the new name to update : ");
		String name = sc.next();
		System.out.println("Enter the ID whose name you want to update : ");
		int id = sc.nextInt();
		
		// set user given values into query
		q.setParameter("sname" , name);
		q.setParameter("stuid", id);
		
		// execute the query
		transaction.begin();
		int rows = q.executeUpdate();
		transaction.commit();
		
		if(rows == 0) {
			System.out.println("Student ID not found. Updation failed.");
		}
		else {
			System.out.println(rows+" student details updated.");
		}
	}
}
