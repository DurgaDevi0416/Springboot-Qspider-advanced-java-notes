package hql_dynamic_proggrams;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class UpdatingDynamicallyUsingHql {

	public static void main(String[] args) {
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("dev");
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		
		// Create dynamic HQL query using positional parameters
		Query q = manager.createQuery("update Student s set s.name=?1 where s.sid=?2 ");
		
		// take input from user
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the new name to update : ");
		String name = sc.next();
		System.out.println("Enter the ID whose name you want to update : ");
		int id = sc.nextInt();
		
		// set user given values into query
		q.setParameter(1, name);
		q.setParameter(2, id);
		
		// execute the query
		transaction.begin();
		int rows = q.executeUpdate();
		transaction.commit();
		
		if(rows == 0) {
			System.out.println("Student ID not found. Updation failed.");
		}
		else {
			System.out.println(rows+" student details updated.");
		}
	}
}












