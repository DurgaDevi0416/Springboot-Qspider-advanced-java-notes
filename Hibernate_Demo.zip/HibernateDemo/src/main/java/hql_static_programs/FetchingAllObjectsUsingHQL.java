package hql_static_programs;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import static_programs.Student;

public class FetchingAllObjectsUsingHQL {

	public static void main(String[] args) {
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("dev");
		EntityManager manager = factory.createEntityManager();
		
		Query q = manager.createQuery("select s from Student s");
		
		List<Student> list = q.getResultList();
		
		if(list.isEmpty()) {
			System.out.println("No student data found");
		}
		else {
			for(Student stu : list) {
				System.out.println("ID : "+stu.getSid());
				System.out.println("NAME : "+stu.getName());
				System.out.println("AGE : "+stu.getAge());
			}
		}
	}
}


































