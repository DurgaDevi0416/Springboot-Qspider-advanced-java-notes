package hql_static_programs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class UpdateStudentObjectUsingHql {

	public static void main(String[] args) {
	
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("dev");
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		
		Query q = manager.createQuery("update Student s set s.name='Mala' where s.sid=1");
	
		transaction.begin();
		int rows = q.executeUpdate();
		transaction.commit();
		
		if(rows == 0) {
			System.out.println("Could not update Student details. ID not found.");
		}
		else {
			System.out.println(rows+" student details updated.");
		}
	}
}














